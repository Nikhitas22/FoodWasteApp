import streamlit as st

st.set_page_config(page_title="Food Waste Management", layout="wide")
st.markdown("# 🍽️ Food Waste Management System")
st.markdown("Navigate using the sidebar to explore project modules.")
