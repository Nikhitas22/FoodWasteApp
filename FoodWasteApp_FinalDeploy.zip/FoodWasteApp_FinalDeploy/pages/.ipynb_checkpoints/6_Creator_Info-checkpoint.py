import streamlit as st
st.set_page_config(layout="wide")
st.title("👨‍💻 Creator Info")
st.markdown("""
### Developed By:
**Name:** Nikhita  
**Email:** nikhita22pujar@gmail.com  
**GitHub:** [github.com/Nikhitas22](https://github.com/Nikhitas22)

This app is built as a mini project to tackle food wastage and improve food redistribution.
""")
