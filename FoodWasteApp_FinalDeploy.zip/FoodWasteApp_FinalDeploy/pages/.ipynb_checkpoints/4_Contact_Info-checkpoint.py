import streamlit as st
import pandas as pd
from utils import get_connection

st.set_page_config(page_title="Contact Information", layout="wide")
st.title("📞 Contact Information")

st.markdown("Use the dropdowns below to filter contact information for **Providers** and **Receivers** by City and Type.")

# Database connection
conn = get_connection()

tab1, tab2 = st.tabs(["📦 Providers", "🎯 Receivers"])

with tab1:
    st.subheader("Provider Contacts")

    # Fetch unique cities and types from providers table
    city_df = pd.read_sql("SELECT DISTINCT city FROM providers", conn)
    type_df = pd.read_sql("SELECT DISTINCT type FROM providers", conn)

    selected_city = st.selectbox("Select City", city_df["city"].dropna().tolist())
    selected_type = st.selectbox("Select Provider Type", type_df["type"].dropna().tolist())

    # Query provider contacts based on filters
    query = f"""
        SELECT name AS provider_name, type AS provider_type, city, contact 
        FROM providers 
        WHERE city = '{selected_city}' AND type = '{selected_type}';
    """
    result_df = pd.read_sql(query, conn)
    st.dataframe(result_df, use_container_width=True)

with tab2:
    st.subheader("Receiver Contacts")

    # Fetch unique cities and types from receivers table
    city_df = pd.read_sql("SELECT DISTINCT city FROM receivers", conn)
    type_df = pd.read_sql("SELECT DISTINCT type FROM receivers", conn)

    selected_city = st.selectbox("Select City", city_df["city"].dropna().tolist(), key="receiver_city")
    selected_type = st.selectbox("Select Receiver Type", type_df["type"].dropna().tolist(), key="receiver_type")

    # Query receiver contacts based on filters
    query = f"""
        SELECT name AS receiver_name, type AS receiver_type, city, contact 
        FROM receivers 
        WHERE city = '{selected_city}' AND type = '{selected_type}';
    """
    result_df = pd.read_sql(query, conn)
    st.dataframe(result_df, use_container_width=True)

conn.close()
