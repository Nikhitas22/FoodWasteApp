import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from utils import fetch_query

st.set_page_config(layout="wide")
st.title("📊 Data Overview")

# Select which table to explore
table_option = st.selectbox("📁 Choose a Table to Explore", ["foodlistings", "providers", "receivers", "claims"])

if table_option == "foodlistings":
    st.subheader("🍱 Food Listings Data")
    df = fetch_query("SELECT * FROM foodlistings")

    if df.empty:
        st.warning("⚠️ No data available in the foodlistings table.")
        st.stop()

    # Filters
    locations = fetch_query("SELECT DISTINCT location FROM foodlistings")
    providers = fetch_query("SELECT DISTINCT provider_type FROM foodlistings")
    food_types = fetch_query("SELECT DISTINCT food_type FROM foodlistings")

    location_filter = st.selectbox("📍 Select Location", ["All"] + sorted(locations["location"].dropna().tolist()))
    provider_filter = st.selectbox("🏢 Select Provider Type", ["All"] + sorted(providers["provider_type"].dropna().tolist()))
    food_type_filter = st.selectbox("🍛 Select Food Type", ["All"] + sorted(food_types["food_type"].dropna().tolist()))

    # Apply filters
    if location_filter != "All":
        df = df[df["location"] == location_filter]
    if provider_filter != "All":
        df = df[df["provider_type"] == provider_filter]
    if food_type_filter != "All":
        df = df[df["food_type"] == food_type_filter]

    # Display data
    st.dataframe(df, use_container_width=True)

    # Charts
    st.subheader("📈 Food Type Distribution")
    food_type_counts = df["food_type"].value_counts()
    fig1, ax1 = plt.subplots()
    food_type_counts.plot(kind="bar", color="skyblue", ax=ax1)
    ax1.set_title("Food Type Distribution")
    ax1.set_ylabel("Count")
    st.pyplot(fig1)

    st.subheader("🍽️ Quantity by Meal Type")
    meal_type_quantity = df.groupby("meal_type")["quantity"].sum()
    fig2, ax2 = plt.subplots()
    meal_type_quantity.plot(kind="pie", autopct="%1.1f%%", ax=ax2)
    ax2.set_ylabel("")
    ax2.set_title("Meal Type Quantity Share")
    st.pyplot(fig2)

elif table_option == "providers":
    st.subheader("🏢 Providers Data")
    df = fetch_query("SELECT * FROM providers")

    if df.empty:
        st.warning("⚠️ No data available in the providers table.")
        st.stop()

    city_filter = st.selectbox("🌆 Select City", ["All"] + sorted(df["city"].dropna().unique()))
    type_filter = st.selectbox("🏬 Select Provider Type", ["All"] + sorted(df["type"].dropna().unique()))

    if city_filter != "All":
        df = df[df["city"] == city_filter]
    if type_filter != "All":
        df = df[df["type"] == type_filter]

    st.dataframe(df, use_container_width=True)

elif table_option == "receivers":
    st.subheader("🙋 Receivers Data")
    df = fetch_query("SELECT * FROM receivers")

    if df.empty:
        st.warning("⚠️ No data available in the receivers table.")
        st.stop()

    city_filter = st.selectbox("🌆 Select City", ["All"] + sorted(df["city"].dropna().unique()))
    type_filter = st.selectbox("🏬 Select Receiver Type", ["All"] + sorted(df["type"].dropna().unique()))

    if city_filter != "All":
        df = df[df["city"] == city_filter]
    if type_filter != "All":
        df = df[df["type"] == type_filter]

    st.dataframe(df, use_container_width=True)

elif table_option == "claims":
    st.subheader("📋 Claims Data")
    df = fetch_query("SELECT * FROM claims")

    if df.empty:
        st.warning("⚠️ No data available in the claims table.")
        st.stop()

    st.dataframe(df, use_container_width=True)

    # Status distribution chart
    st.subheader("✅ Claims by Status")
    status_counts = df["status"].value_counts()
    fig, ax = plt.subplots()
    status_counts.plot(kind="bar", color="orange", ax=ax)
    ax.set_title("Claims by Status")
    ax.set_ylabel("Count")
    st.pyplot(fig)
