import streamlit as st
from PIL import Image

st.set_page_config(layout="wide")
st.title("Welcome to the Food Waste Management System")
# Centered image in 3 columns
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    banner = Image.open("fwm.png")
    st.image(banner, width=500)



# Project description
st.markdown("""
## 📌 Project Overview

Food wastage is a serious issue affecting both the environment and the society. This Local Food Waste Management System aims to reduce food wastage by connecting **food providers** (like restaurants, hotels, or caterers) with **receivers** (such as NGOs and orphanages) who can make use of excess food.

This system includes:
- 📦 Listing of excess food items by providers
- 📥 Claiming of listed food items by receivers
- 🗃️ Central database storing food, providers, receivers, and claims
- 📊 Insights from SQL queries
- 🛠️ Full CRUD operations on all key data
- 📍 Filters by city and provider type

---

## 🎯 Goals
- Reduce food waste
- Improve distribution efficiency
- Help communities in need
- Provide data-driven insights

""")

