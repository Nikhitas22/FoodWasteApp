import streamlit as st
import pandas as pd
from utils import fetch_query, run_query

st.set_page_config(layout="wide")
st.title("🛠️ CRUD Operations")

# Dropdown to select table
table = st.selectbox("Select Table to Manage", ["providers", "receivers", "foodlistings", "claims"])

# Utility function to reload table data
def load_data(table_name):
    try:
        data = fetch_query(f"SELECT * FROM {table_name}")
        return data
    except Exception as e:
        st.error(f"❌ Error loading data from {table_name}: {e}")
        return pd.DataFrame()

# Add Record
st.subheader(f"➕ Add New Record to {table.capitalize()}")

with st.form(f"add_form_{table}"):
    if table == "providers":
        name = st.text_input("Name")
        type_ = st.text_input("Type")
        address = st.text_area("Address")
        city = st.text_input("City")
        contact = st.text_input("Contact")
        submitted = st.form_submit_button("Add Provider")
        if submitted:
            run_query(
                "INSERT INTO providers (name, type, address, city, contact) VALUES (%s, %s, %s, %s, %s);",
                (name, type_, address, city, contact)
            )
            st.success("✅ Provider added successfully.")

    elif table == "receivers":
        name = st.text_input("Name")
        type_ = st.text_input("Type")
        city = st.text_input("City")
        contact = st.text_input("Contact")
        submitted = st.form_submit_button("Add Receiver")
        if submitted:
            run_query(
                "INSERT INTO receivers (name, type, city, contact) VALUES (%s, %s, %s, %s);",
                (name, type_, city, contact)
            )
            st.success("✅ Receiver added successfully.")

    elif table == "foodlistings":
        food_name = st.text_input("Food Name")
        quantity = st.number_input("Quantity", min_value=1)
        expiry_date = st.date_input("Expiry Date")
        provider_id = st.number_input("Provider ID", min_value=1)
        provider_type = st.text_input("Provider Type")
        location = st.text_input("Location")
        food_type = st.text_input("Food Type")
        meal_type = st.text_input("Meal Type")
        submitted = st.form_submit_button("Add Food Listing")
        if submitted:
            run_query(
                """INSERT INTO foodlistings (food_name, quantity, expiry_date, provider_id, provider_type, location, food_type, meal_type)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s);""",
                (food_name, quantity, expiry_date, provider_id, provider_type, location, food_type, meal_type)
            )
            st.success("✅ Food listing added successfully.")

    elif table == "claims":
        food_id = st.number_input("Food ID", min_value=1)
        receiver_id = st.number_input("Receiver ID", min_value=1)
        status = st.selectbox("Status", ["Pending", "Completed", "Canceled"])
        submitted = st.form_submit_button("Add Claim")
        if submitted:
            run_query(
                "INSERT INTO claims (food_id, receiver_id, status, timestamp) VALUES (%s, %s, %s, NOW());",
                (food_id, receiver_id, status)
            )
            st.success("✅ Claim added successfully.")

# Display Data
st.subheader(f"📋 Existing Records in {table.capitalize()}")
df = load_data(table)
if not df.empty:
    st.dataframe(df, use_container_width=True)

    # Update and Delete
    st.subheader(f"✏️ Update / ❌ Delete Record in {table.capitalize()}")

    selected_id_col = df.columns[0]
    selected_id = st.selectbox("Select ID to Update/Delete", df[selected_id_col].tolist())

    record = df[df[selected_id_col] == selected_id].iloc[0]

    with st.form(f"update_form_{table}"):
        updated_values = []
        for col in df.columns[1:]:
            new_value = st.text_input(f"{col}", value=str(record[col]))
            updated_values.append(new_value)

        col1, col2 = st.columns(2)
        with col1:
            update_btn = st.form_submit_button("Update")
        with col2:
            delete_btn = st.form_submit_button("Delete")

        if update_btn:
            set_clause = ", ".join([f"{col} = %s" for col in df.columns[1:]])
            query = f"UPDATE {table} SET {set_clause} WHERE {selected_id_col} = %s"
            run_query(query, (*updated_values, selected_id))
            st.success(f"✅ Record {selected_id} updated successfully.")

        if delete_btn:
            run_query(f"DELETE FROM {table} WHERE {selected_id_col} = %s", (selected_id,))
            st.success(f"🗑️ Record {selected_id} deleted successfully.")
else:
    st.warning(f"⚠️ No records found in {table}.")
