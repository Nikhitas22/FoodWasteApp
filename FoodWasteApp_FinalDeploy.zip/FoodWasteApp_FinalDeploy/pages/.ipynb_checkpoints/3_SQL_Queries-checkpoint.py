import streamlit as st
import pandas as pd
import plotly.express as px
from utils import fetch_query

st.set_page_config(layout="wide")
st.title("📊 SQL Insights")

queries = {
    "1️⃣ Which city has the highest number of food providers?":
        "SELECT city, COUNT(*) AS provider_count FROM providers GROUP BY city ORDER BY provider_count DESC;",
    
    "2️⃣ What type of food is most commonly listed?":
        "SELECT food_type, COUNT(*) AS count FROM foodlistings GROUP BY food_type ORDER BY count DESC;",
    
    "3️⃣ What is the contact information of food providers in a specific city?":
        "SELECT name, contact, city FROM providers WHERE city = 'Dharwad';",
    
    "4️⃣ How many food listings are there for each meal type?":
        "SELECT meal_type, COUNT(*) AS count FROM foodlistings GROUP BY meal_type;",
    
    "5️⃣ What is the average quantity of food donated per listing?":
        "SELECT AVG(quantity) AS avg_quantity FROM foodlistings;",
    
    "6️⃣ Which receiver has claimed the most food items?":
        """SELECT r.name, COUNT(c.claim_id) AS total_claims
           FROM receivers r
           JOIN claims c ON r.receiver_id = c.receiver_id
           GROUP BY r.name ORDER BY total_claims DESC LIMIT 1;""",
    
    "7️⃣ What are the top 5 most listed food items?":
        "SELECT food_name, COUNT(*) AS count FROM foodlistings GROUP BY food_name ORDER BY count DESC LIMIT 5;",
    
    "8️⃣ What is the distribution of food types?":
        "SELECT food_type, COUNT(*) AS count FROM foodlistings GROUP BY food_type;",
    
    "9️⃣ Which provider has listed the most food?":
        """SELECT p.name, COUNT(f.food_id) AS total_listings
           FROM providers p
           JOIN foodlistings f ON p.provider_id = f.provider_id
           GROUP BY p.name ORDER BY total_listings DESC LIMIT 1;""",
    
    "🔟 What percentage of food claims are completed vs. pending vs. canceled?":
        """SELECT status, COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () AS percentage
           FROM claims GROUP BY status;""",
    
    "1️⃣1️⃣ How many food items are near expiry (within 3 days)?":
        "SELECT COUNT(*) AS near_expiry FROM foodlistings WHERE expiry_date <= CURRENT_DATE + INTERVAL '3 days';",
    
    "1️⃣2️⃣ Which provider types are most active in donations?":
        "SELECT provider_type, COUNT(*) AS count FROM foodlistings GROUP BY provider_type ORDER BY count DESC;",
    
    "1️⃣3️⃣ What is the total quantity of food donated by each provider?":
        """SELECT p.name, SUM(f.quantity) AS total_quantity
           FROM providers p
           JOIN foodlistings f ON p.provider_id = f.provider_id
           GROUP BY p.name ORDER BY total_quantity DESC;""",
    
    "1️⃣4️⃣ What is the monthly trend of food listings?":
        """SELECT DATE_TRUNC('month', expiry_date) AS month, COUNT(*) AS total_listings
           FROM foodlistings GROUP BY month ORDER BY month;""",
    
    "1️⃣5️⃣ What is the most common meal type per city?":
        """SELECT city, meal_type, COUNT(*) AS count FROM (
             SELECT f.meal_type, p.city FROM foodlistings f
             JOIN providers p ON f.provider_id = p.provider_id
           ) AS combined
           GROUP BY city, meal_type
           ORDER BY city, count DESC;""",
    
    "1️⃣6️⃣ Which city has the most receivers?":
        "SELECT city, COUNT(*) AS receiver_count FROM receivers GROUP BY city ORDER BY receiver_count DESC;",
    
    "1️⃣7️⃣ What is the average time between food listing and claim?":
        """SELECT AVG(c.timestamp - f.expiry_date) AS avg_delay
           FROM claims c JOIN foodlistings f ON c.food_id = f.food_id;""",
    
    "1️⃣8️⃣ What are the claim statuses per receiver?":
        """SELECT r.name, c.status, COUNT(*) AS count
           FROM receivers r JOIN claims c ON r.receiver_id = c.receiver_id
           GROUP BY r.name, c.status ORDER BY r.name;""",
    
    "1️⃣9️⃣ Which food type is most claimed?":
        """SELECT f.food_type, COUNT(*) AS count
           FROM claims c JOIN foodlistings f ON c.food_id = f.food_id
           GROUP BY f.food_type ORDER BY count DESC LIMIT 1;""",
    
    "2️⃣0️⃣ What is the daily trend of claims?":
        """SELECT DATE(timestamp) AS claim_date, COUNT(*) AS total_claims
           FROM claims GROUP BY claim_date ORDER BY claim_date;""",
    
    "2️⃣1️⃣ Which providers and receivers have the strongest match rate?":
        """SELECT p.name AS provider, r.name AS receiver, COUNT(*) AS claims_count
           FROM claims c
           JOIN foodlistings f ON c.food_id = f.food_id
           JOIN providers p ON f.provider_id = p.provider_id
           JOIN receivers r ON c.receiver_id = r.receiver_id
           GROUP BY p.name, r.name ORDER BY claims_count DESC LIMIT 5;""",
    
    "2️⃣2️⃣ What is the number of claims by provider type?":
        """SELECT provider_type, COUNT(*) AS claim_count
           FROM claims c JOIN foodlistings f ON c.food_id = f.food_id
           GROUP BY provider_type;""",
    
    "2️⃣3️⃣ Which food types are mostly listed by restaurants?":
        """SELECT food_type, COUNT(*) AS count
           FROM foodlistings WHERE provider_type = 'Restaurant'
           GROUP BY food_type ORDER BY count DESC;""",
    
    "2️⃣4️⃣ Which providers have never had their food claimed?":
        """SELECT DISTINCT p.name FROM providers p
           WHERE p.provider_id NOT IN (
             SELECT DISTINCT f.provider_id FROM foodlistings f
             JOIN claims c ON f.food_id = c.food_id
           );"""
}

query_names = list(queries.keys())
selected_question = st.selectbox("🧠 Select a SQL Insight", query_names)

query = queries[selected_question]
st.markdown(f"### 💡 Insight:\n`{selected_question}`")

try:
    df = fetch_query(query)
    if df.empty:
        st.warning("No results found for this query.")
    else:
        st.dataframe(df, use_container_width=True)

        if df.shape[1] >= 2:
            chart = px.bar(df, x=df.columns[0], y=df.columns[1], color=df.columns[0])
            st.plotly_chart(chart, use_container_width=True)
except Exception as e:
    st.error(f"Error executing query: {e}")
